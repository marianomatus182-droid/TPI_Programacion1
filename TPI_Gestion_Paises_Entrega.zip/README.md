# TPI - Gestión de Datos de Países en Python

Carrera: Tecnicatura Universitaria en Programación a Distancia  
Materia: Programación 1  
Integrantes: Agustin Seoane y Gabriel Matus
Fecha de entrega: 16/11/25  
Repositorio público: https://github.com/marianomatus182-droid/TPI_Programacion1

## Descripción

Programa de consola escrito en Python 3 que lee datos de países desde un archivo CSV y permite agregarlos, actualizar población y superficie, buscar, filtrar, ordenar y calcular estadísticas. Usa listas de diccionarios, funciones, condicionales, bucles y validaciones. Los cambios de altas y actualizaciones se guardan automáticamente en `paises.csv`.

## Requisitos e instalación

Se necesita Python 3.9 o superior. No requiere paquetes adicionales.

1. Descargar o clonar el repositorio y abrir la terminal dentro de la carpeta del proyecto.
2. Ejecutar `python main.py` (o `python3 main.py` en sistemas donde corresponda).
3. Seleccionar una opción del menú. `0` finaliza el programa.

Para ejecutar las pruebas: `python -m unittest discover -s tests -v`.

## Formato de datos

El archivo `paises.csv` es UTF-8 y utiliza las columnas en este orden:

```csv
nombre,poblacion,superficie,continente
Argentina,45376763,2780400,América
Japón,125800000,377975,Asia
```

La población debe ser un entero no negativo y la superficie un entero mayor a cero. Los nombres y continentes no pueden estar vacíos. El conjunto base contiene **valores de ejemplo para fines académicos**: no debe interpretarse como una base estadística actualizada ni homogénea en fecha de referencia.

## Menú

```text
1. Agregar país
2. Actualizar población y superficie
3. Buscar país por nombre
4. Filtrar países
5. Ordenar países
6. Mostrar estadísticas
7. Listar todos los países
0. Salir
```

## Ejemplos de uso (entradas y salidas)

**Buscar por nombre parcial:**

```text
Seleccione una opción: 3
Nombre o fragmento: arg
PAÍS                          POBLACIÓN   SUPERFICIE (km²)  CONTINENTE
-------------------------------------------------------------------------
Argentina                    45,376,763          2,780,400  América
Total: 1 país(es).
```

**Filtrar por continente:**

```text
Seleccione una opción: 4
Filtrar por: 1) Continente  2) Rango de población  3) Rango de superficie
Opción: 1
Continente: Oceanía
PAÍS                          POBLACIÓN   SUPERFICIE (km²)  CONTINENTE
-------------------------------------------------------------------------
Australia                    25,687,041          7,692,024  Oceanía
Nueva Zelanda                 5,122,600            268,838  Oceanía
Total: 2 país(es).
```

**Validación de opción inválida:**

```text
Seleccione una opción: 9
Error: opción de menú inválida.
```

## Decisiones técnicas

- Lista de diccionarios: cada país tiene `nombre`, `poblacion`, `superficie` y `continente`.
- Funciones independientes para lectura, escritura, validación, búsqueda, filtrado, ordenamiento y estadísticas.
- Coincidencias de nombres sin distinción de mayúsculas y tildes.
- `csv.DictReader` y `csv.DictWriter` para lectura y escritura; se informan filas inválidas y se ignoran.
- Los ordenamientos generan una lista nueva (no alteran la base en memoria).
- La persistencia se ejecuta tras agregar o actualizar, no al buscar o filtrar.

## Distribución del trabajo (completar con el aporte real)

| Integrante | Actividades realizadas |
|---|---|
| [NOMBRE 1] | [DESCRIBIR CONTRIBUCIONES REALES] |
| [NOMBRE 2] | [DESCRIBIR CONTRIBUCIONES REALES] |

## Entregables y enlaces obligatorios

- Video: https://youtu.be/SgqKcYiPxUg
- Informe PDF: file:///C:/Users/Usuario/AppData/Local/Temp/58619cc4-434e-44d0-a1a2-b5869679af11_TPI_Gestion_Paises_Entrega.zip.f11/Informe_TPI_Gestion_Paises.pdf
- Repositorio GitHub: https://github.com/marianomatus182-droid/TPI_Programacion1
