"""Trabajo Práctico Integrador: gestión de países desde un CSV (Python 3)."""
import csv
import unicodedata
from pathlib import Path

ARCHIVO_CSV = Path(__file__).resolve().parent / "paises.csv"
CAMPOS = ("nombre", "poblacion", "superficie", "continente")


def normalizar(texto):
    """Permite comparar nombres sin importar mayúsculas ni tildes."""
    texto = unicodedata.normalize("NFD", texto.strip().casefold())
    return "".join(letra for letra in texto if unicodedata.category(letra) != "Mn")


def validar_pais(nombre, poblacion, superficie, continente):
    """Devuelve un diccionario válido o genera ValueError."""
    nombre, continente = nombre.strip(), continente.strip()
    if not nombre or not continente:
        raise ValueError("Nombre y continente no pueden estar vacíos.")
    if not str(poblacion).strip() or not str(superficie).strip():
        raise ValueError("Población y superficie no pueden estar vacías.")
    try:
        poblacion, superficie = int(poblacion), int(superficie)
    except (TypeError, ValueError) as error:
        raise ValueError("Población y superficie deben ser números enteros.") from error
    if poblacion < 0 or superficie <= 0:
        raise ValueError("La población no puede ser negativa y la superficie debe ser mayor a cero.")
    return {"nombre": nombre, "poblacion": poblacion,
            "superficie": superficie, "continente": continente}


def cargar_paises(ruta=ARCHIVO_CSV):
    """Lee el CSV; descarta filas inválidas e informa el motivo."""
    paises = []
    vistos = set()
    try:
        with open(ruta, "r", encoding="utf-8-sig", newline="") as archivo:
            lector = csv.DictReader(archivo)
            if lector.fieldnames is None or tuple(lector.fieldnames) != CAMPOS:
                raise ValueError("Encabezado CSV inválido; se esperan: " + ",".join(CAMPOS))
            for numero, fila in enumerate(lector, start=2):
                try:
                    if None in fila or any(fila[campo] is None for campo in CAMPOS):
                        raise ValueError("Cantidad de columnas incorrecta")
                    pais = validar_pais(*(fila[campo] for campo in CAMPOS))
                    clave = normalizar(pais["nombre"])
                    if clave in vistos:
                        raise ValueError("País duplicado")
                    vistos.add(clave)
                    paises.append(pais)
                except ValueError as error:
                    print(f"Aviso: fila {numero} ignorada: {error}")
    except FileNotFoundError:
        print("Aviso: no existe el CSV; se iniciará una base vacía.")
    except (OSError, UnicodeError, csv.Error) as error:
        print(f"Error al leer CSV: {error}. Se iniciará una base vacía.")
    except ValueError as error:
        print(f"Error de formato CSV: {error}. Se iniciará una base vacía.")
    return paises


def guardar_paises(paises, ruta=ARCHIVO_CSV):
    """Persiste el listado completo a CSV; comunica errores al llamador."""
    with open(ruta, "w", encoding="utf-8", newline="") as archivo:
        escritor = csv.DictWriter(archivo, fieldnames=CAMPOS)
        escritor.writeheader()
        escritor.writerows(paises)


def buscar_paises(paises, texto):
    termino = normalizar(texto)
    if not termino:
        return []
    return [pais for pais in paises if termino in normalizar(pais["nombre"])]


def agregar_pais(paises, pais):
    if any(normalizar(p["nombre"]) == normalizar(pais["nombre"]) for p in paises):
        raise ValueError("Ya existe un país con ese nombre.")
    paises.append(pais)


def actualizar_pais(paises, nombre, poblacion, superficie):
    encontrados = [p for p in paises if normalizar(p["nombre"]) == normalizar(nombre)]
    if not encontrados:
        raise ValueError("No se encontró un país con ese nombre exacto.")
    previo = encontrados[0]
    actualizado = validar_pais(previo["nombre"], poblacion, superficie, previo["continente"])
    previo.update(actualizado)


def filtrar_continente(paises, continente):
    return [p for p in paises if normalizar(p["continente"]) == normalizar(continente)]


def filtrar_rango(paises, campo, minimo, maximo):
    if campo not in ("poblacion", "superficie"):
        raise ValueError("Campo de filtro incorrecto.")
    if minimo > maximo:
        raise ValueError("El mínimo no puede superar al máximo.")
    return [p for p in paises if minimo <= p[campo] <= maximo]


def ordenar_paises(paises, campo, descendente=False):
    if campo not in ("nombre", "poblacion", "superficie"):
        raise ValueError("Criterio de ordenamiento inválido.")
    return sorted(paises, key=(lambda p: normalizar(p[campo])) if campo == "nombre"
                  else (lambda p: p[campo]), reverse=descendente)


def estadisticas(paises):
    if not paises:
        return None
    cantidades = {}
    for p in paises:
        cantidades[p["continente"]] = cantidades.get(p["continente"], 0) + 1
    return {
        "mayor": max(paises, key=lambda p: p["poblacion"]),
        "menor": min(paises, key=lambda p: p["poblacion"]),
        "promedio_poblacion": sum(p["poblacion"] for p in paises) / len(paises),
        "promedio_superficie": sum(p["superficie"] for p in paises) / len(paises),
        "por_continente": dict(sorted(cantidades.items())),
    }


def solicitar_texto(mensaje):
    while True:
        valor = input(mensaje).strip()
        if valor:
            return valor
        print("Error: este campo no puede quedar vacío.")


def solicitar_entero(mensaje, minimo=0):
    while True:
        try:
            valor = int(solicitar_texto(mensaje))
            if valor < minimo:
                print(f"Error: ingresar un entero mayor o igual a {minimo}.")
                continue
            return valor
        except ValueError:
            print("Error: ingresar un número entero válido.")


def mostrar_paises(paises):
    if not paises:
        print("No se encontraron países para mostrar.")
        return
    print(f"{'PAÍS':<23} {'POBLACIÓN':>15} {'SUPERFICIE (km²)':>18}  CONTINENTE")
    print("-" * 73)
    for pais in paises:
        print(f"{pais['nombre']:<23} {pais['poblacion']:>15,} {pais['superficie']:>18,}  {pais['continente']}")
    print(f"Total: {len(paises)} país(es).")


def ejecutar_agregar(paises):
    print("\n--- Agregar país ---")
    pais = validar_pais(solicitar_texto("Nombre: "),
                        solicitar_entero("Población: "),
                        solicitar_entero("Superficie en km²: ", minimo=1),
                        solicitar_texto("Continente: "))
    agregar_pais(paises, pais)
    print("Éxito: país agregado.")


def ejecutar_actualizar(paises):
    print("\n--- Actualizar población y superficie ---")
    nombre = solicitar_texto("Nombre exacto del país: ")
    if not any(normalizar(p["nombre"]) == normalizar(nombre) for p in paises):
        print("Error: país inexistente.")
        return False
    poblacion = solicitar_entero("Nueva población: ")
    superficie = solicitar_entero("Nueva superficie en km²: ", minimo=1)
    actualizar_pais(paises, nombre, poblacion, superficie)
    print("Éxito: datos actualizados.")
    return True


def ejecutar_filtros(paises):
    print("\nFiltrar por: 1) Continente  2) Rango de población  3) Rango de superficie")
    opcion = input("Opción: ").strip()
    if opcion == "1":
        resultado = filtrar_continente(paises, solicitar_texto("Continente: "))
    elif opcion in ("2", "3"):
        campo = "poblacion" if opcion == "2" else "superficie"
        minimo = solicitar_entero("Valor mínimo: ")
        maximo = solicitar_entero("Valor máximo: ")
        resultado = filtrar_rango(paises, campo, minimo, maximo)
    else:
        print("Error: opción de filtro inválida.")
        return
    mostrar_paises(resultado)


def ejecutar_ordenamiento(paises):
    print("\nOrdenar por: 1) Nombre  2) Población  3) Superficie")
    opcion = input("Opción: ").strip()
    campos = {"1": "nombre", "2": "poblacion", "3": "superficie"}
    if opcion not in campos:
        print("Error: criterio inválido.")
        return
    direccion = input("Dirección (A=ascendente / D=descendente): ").strip().upper()
    if direccion not in ("A", "D"):
        print("Error: dirección inválida.")
        return
    mostrar_paises(ordenar_paises(paises, campos[opcion], direccion == "D"))


def mostrar_estadisticas(paises):
    datos = estadisticas(paises)
    if datos is None:
        print("No hay datos disponibles para calcular estadísticas.")
        return
    print("\n--- Estadísticas ---")
    print(f"Mayor población: {datos['mayor']['nombre']} ({datos['mayor']['poblacion']:,})")
    print(f"Menor población: {datos['menor']['nombre']} ({datos['menor']['poblacion']:,})")
    print(f"Promedio de población: {datos['promedio_poblacion']:,.2f}")
    print(f"Promedio de superficie: {datos['promedio_superficie']:,.2f} km²")
    print("Cantidad de países por continente:")
    for continente, cantidad in datos["por_continente"].items():
        print(f"  {continente}: {cantidad}")


def menu():
    paises = cargar_paises()
    while True:
        print("\n========== GESTIÓN DE PAÍSES ==========")
        print("1. Agregar país")
        print("2. Actualizar población y superficie")
        print("3. Buscar país por nombre")
        print("4. Filtrar países")
        print("5. Ordenar países")
        print("6. Mostrar estadísticas")
        print("7. Listar todos los países")
        print("0. Salir")
        try:
            opcion = input("Seleccione una opción: ").strip()
            if opcion == "0":
                print("Programa finalizado.")
                break
            elif opcion == "1":
                ejecutar_agregar(paises)
                guardar_paises(paises)
                print("Datos guardados en el CSV.")
            elif opcion == "2":
                if ejecutar_actualizar(paises):
                    guardar_paises(paises)
                    print("Datos guardados en el CSV.")
            elif opcion == "3":
                mostrar_paises(buscar_paises(paises, solicitar_texto("Nombre o fragmento: ")))
            elif opcion == "4":
                ejecutar_filtros(paises)
            elif opcion == "5":
                ejecutar_ordenamiento(paises)
            elif opcion == "6":
                mostrar_estadisticas(paises)
            elif opcion == "7":
                mostrar_paises(paises)
            else:
                print("Error: opción de menú inválida.")
        except (ValueError, OSError) as error:
            print(f"Error: {error}")
        except (KeyboardInterrupt, EOFError):
            print("\nEntrada interrumpida. Programa finalizado.")
            break


if __name__ == "__main__":
    menu()
