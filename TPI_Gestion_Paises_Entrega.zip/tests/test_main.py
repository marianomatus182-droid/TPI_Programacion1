import csv
import tempfile
import unittest
from pathlib import Path
from main import (validar_pais, cargar_paises, guardar_paises, agregar_pais,
                  actualizar_pais, buscar_paises, filtrar_continente,
                  filtrar_rango, ordenar_paises, estadisticas)


class TestGestionPaises(unittest.TestCase):
    def setUp(self):
        self.paises = [validar_pais("Argentina", 45, 100, "América"),
                       validar_pais("Japón", 125, 30, "Asia"),
                       validar_pais("Brasil", 200, 300, "América")]

    def test_validacion(self):
        for args in [("", 10, 10, "Asia"), ("Chile", "x", 20, "América"),
                     ("Chile", 2, 0, "América"), ("Chile", -1, 2, "América")]:
            with self.assertRaises(ValueError):
                validar_pais(*args)

    def test_agregar_duplicado_y_actualizar(self):
        with self.assertRaises(ValueError):
            agregar_pais(self.paises, validar_pais("ARGENTINA", 10, 10, "América"))
        actualizar_pais(self.paises, "argentina", 50, 101)
        self.assertEqual(self.paises[0]["poblacion"], 50)
        self.assertEqual(self.paises[0]["superficie"], 101)

    def test_busquedas_filtros(self):
        self.assertEqual(len(buscar_paises(self.paises, "JAPON")), 1)
        self.assertEqual(len(buscar_paises(self.paises, "a")), 3)
        self.assertEqual(len(filtrar_continente(self.paises, "america")), 2)
        self.assertEqual(len(filtrar_rango(self.paises, "poblacion", 40, 130)), 2)
        with self.assertRaises(ValueError):
            filtrar_rango(self.paises, "superficie", 200, 10)

    def test_ordenamiento_y_estadisticas(self):
        self.assertEqual(ordenar_paises(self.paises, "poblacion", True)[0]["nombre"], "Brasil")
        self.assertEqual(ordenar_paises(self.paises, "nombre")[0]["nombre"], "Argentina")
        datos = estadisticas(self.paises)
        self.assertEqual(datos["mayor"]["nombre"], "Brasil")
        self.assertEqual(datos["menor"]["nombre"], "Argentina")
        self.assertAlmostEqual(datos["promedio_poblacion"], 370 / 3)
        self.assertEqual(datos["por_continente"]["América"], 2)
        self.assertIsNone(estadisticas([]))

    def test_csv_persistencia_y_filas_invalidas(self):
        with tempfile.TemporaryDirectory() as temp:
            ruta = Path(temp) / "paises.csv"
            guardar_paises(self.paises, ruta)
            self.assertEqual(cargar_paises(ruta), self.paises)
            with ruta.open("a", encoding="utf-8", newline="") as archivo:
                archivo.write("Invalido,x,10,Asia\nArgentina,999,20,América\n")
            self.assertEqual(len(cargar_paises(ruta)), 3)


if __name__ == "__main__":
    unittest.main()
